from django.shortcuts import render, get_object_or_404, redirect
import pandas as pd
import os
from datetime import datetime as dt
from pathlib import Path
from django.views.generic import(View)
from .models import CollisionLocation,ImpactedPeople,Vehicle,BikeStation
from time import strftime,strptime
import numpy as np
from django.shortcuts import HttpResponse
import folium
from folium.plugins import MarkerCluster


# Create your views here.

class homePageView(View):
    def get(self, request, *args, **kwargs):
        return render(request, "index.html")


class loadCollisionData(View):
    def get(self, request, *args, **kwargs):
        baseDir = Path(__file__).resolve().parent.parent
        # crashDataPath = os.path.join(baseDir, 'static', r'Motor_Vehicle_Collisions_-_Crashes.csv')
        crashDataPath = os.path.join(baseDir, 'static', r'collision1000.csv')

        crashData = pd.read_csv(crashDataPath, low_memory=False)
        crashData = crashData[pd.notnull(crashData['BOROUGH'])]
        crashData = crashData.replace(np.nan, '', regex=True)
        print(" original data columns : ", list(crashData.columns))
        CollisionLocation.objects.all().delete()
        ImpactedPeople.objects.all().delete()
        Vehicle.objects.all().delete()
        collisionDf = crashData[['COLLISION_ID','CRASH DATE','CRASH TIME','BOROUGH','ZIP CODE','LATITUDE',
                                'LONGITUDE','LOCATION','ON STREET NAME','CROSS STREET NAME','OFF STREET NAME']].copy()
        print(" last check .....")

        collisionDf['CRASH DATE'] = [strftime('%Y-%m-%d',strptime(i,'%m/%d/%Y')) for i in list(collisionDf['CRASH DATE'])]
        # collisionDf.to_sql(CollisionLocation)
        print('final check...')
        print(" data shape : ",collisionDf.shape)
        coll_row_iter = collisionDf.iterrows()
        collisionObjs = [CollisionLocation(collisionId=row['COLLISION_ID'],crashDate = row['CRASH DATE'],crashTime = row['CRASH TIME'],
                                  borough = row['BOROUGH'],zipCode = row['ZIP CODE'],lattitude = row['LATITUDE'],
                                  longitude = row['LONGITUDE'],location = row['LOCATION'],onStreetName = row['ON STREET NAME'],
                                  crossStreetName = row['CROSS STREET NAME'],offStreetName = row['OFF STREET NAME'] ) for index,row in coll_row_iter]
        CollisionLocation.objects.bulk_create(collisionObjs)
        peopleObjs= []
        peopleDf = crashData[['COLLISION_ID','NUMBER OF PERSONS INJURED', 'NUMBER OF PERSONS KILLED', 'NUMBER OF PEDESTRIANS INJURED',
                              'NUMBER OF PEDESTRIANS KILLED', 'NUMBER OF CYCLIST INJURED', 'NUMBER OF CYCLIST KILLED',
                              'NUMBER OF MOTORIST INJURED', 'NUMBER OF MOTORIST KILLED']].copy()
        people_row_iter=peopleDf.iterrows()
        for index,row in people_row_iter:
            try:
                collisionId = CollisionLocation.objects.get(collisionId=row['COLLISION_ID'])
            except Exception as e:
                collisionId = None
            eachPeopleObj = ImpactedPeople(collisionId=collisionId,numPersonsInjured=row['NUMBER OF PERSONS INJURED'],
                           numPersonsKilled=row['NUMBER OF PERSONS KILLED'],numPedestriansInjured=row['NUMBER OF PEDESTRIANS INJURED'],
                           numPedestriansKilled=row['NUMBER OF PEDESTRIANS KILLED'],numCyclistsInjured=row['NUMBER OF CYCLIST INJURED'],
                           numCyclistsKilled=row['NUMBER OF CYCLIST KILLED'],numMotoristsInjured=row['NUMBER OF MOTORIST INJURED'],
                           numMotoristsKilled=row['NUMBER OF MOTORIST KILLED'])
            peopleObjs.append(eachPeopleObj)
        ImpactedPeople.objects.bulk_create(peopleObjs)

        vehicleObjs = []
        vehicleDf = crashData[['COLLISION_ID','CONTRIBUTING FACTOR VEHICLE 1', 'CONTRIBUTING FACTOR VEHICLE 2',
                               'CONTRIBUTING FACTOR VEHICLE 3', 'CONTRIBUTING FACTOR VEHICLE 4', 'CONTRIBUTING FACTOR VEHICLE 5',
                               'VEHICLE TYPE CODE 1', 'VEHICLE TYPE CODE 2', 'VEHICLE TYPE CODE 3',
                               'VEHICLE TYPE CODE 4', 'VEHICLE TYPE CODE 5']].copy()
        print(set(crashData['COLLISION_ID']))
        vehicle_row_iter = vehicleDf.iterrows()
        for index,row in vehicle_row_iter:
            try:
                collisionId = CollisionLocation.objects.get(collisionId=row['COLLISION_ID'])
            except Exception as e:
                print(str(e))
                collisionId = None

            print('collision id : ',collisionId)
            eachVehicleObj = Vehicle(collisionId=collisionId,contributeVehicle1=row['CONTRIBUTING FACTOR VEHICLE 1'],
                           contributeVehicle2=row['CONTRIBUTING FACTOR VEHICLE 2'],contributeVehicle3=row['CONTRIBUTING FACTOR VEHICLE 3'],
                           contributeVehicle4=row['CONTRIBUTING FACTOR VEHICLE 4'],contributeVehicle5=row['CONTRIBUTING FACTOR VEHICLE 5'],
                           vehicleTypeCode1=row['VEHICLE TYPE CODE 1'],vehicleTypeCode2=row['VEHICLE TYPE CODE 2'],
                           vehicleTypeCode3=row['VEHICLE TYPE CODE 3'],vehicleTypeCode4=row['VEHICLE TYPE CODE 4'],
                           vehicleTypeCode5=row['VEHICLE TYPE CODE 5'])
            vehicleObjs.append(eachVehicleObj)
        Vehicle.objects.bulk_create(vehicleObjs)


        print(" bulk updation performed !!! ")
        return render(request, "index.html")




        


class filterBoroughView(View):
    def get(self,request,*args, **kwargs):
        borough = kwargs['borough']
        #borough = "MANHATTAN"
        #baseDir = Path(__file__).resolve().parent.parent
        #crashDataPath = os.path.join(baseDir,'static',r'collision1000.csv')
        #crashData = pd.read_csv(crashDataPath, low_memory=False)

        crashData = pd.DataFrame(list(CollisionLocation.objects.filter(borough=borough).values()))

        crashData.drop( crashData[ (crashData['lattitude'] == '') | (crashData['longitude'] == '')].index , inplace=True)
        print("data read complete from the collision location model")
        print(crashData.shape)
        try:
            crashData = crashData[crashData['location'].notna()]
        except Exception as e:
            print(" Exception found !!!!!!!!!!!!!!!")
            print(str(e))
        print(" original data columns : ", list(crashData.columns))

        """As per the requirement, we need only the injured / killed cyclist information, 
        hence ignoring the columns related to motorist"""

        injuredCyclistFields = [field for field in crashData.columns if ("motorist" not in field.lower())]
        print(" injured cyclist collision columns : ", injuredCyclistFields)
        print(set(list(crashData['borough'])))
        print(borough)
        outputDf = crashData.loc[crashData['borough'] == borough, injuredCyclistFields]
        print("Data volume based on borough : ", borough, " is ", outputDf.shape)
        print(outputDf.head(5))

        lattitude_list = list(outputDf['lattitude'])
        longitude_list = list(outputDf['longitude'])

        locZip = list(zip(lattitude_list, longitude_list))
        locs = [(lat, lon) for (lat, lon) in locZip if ((str(lat) not in ('nan','')) and (str(lon) not in ('nan','')))]
        print(sorted(locs))
        print(set([(type(lat),type(lon)) for (lat, lon) in locs ]))
        meanLat = sum([float(lat) for (lat, lon) in locs]) / len([lat for (lat, lon) in locs])
        meanLon = sum([float(lon) for (lat, lon) in locs]) / len([lon for (lat, lon) in locs])
        print(meanLat, meanLon)

        boroughMap = folium.Map(location=[meanLat, meanLon], zoom_start=10)
        for (lat, lon, onStreet, crossStreet, offStreet) in zip(outputDf['lattitude'],outputDf['longitude'],outputDf['onStreetName'],outputDf['crossStreetName'],outputDf['offStreetName']) :
            # Marker() takes location coordinates
            # as a list as an argument
            print("[ ",onStreet," ]#####[ ", crossStreet," ]##########[ ", offStreet," ]")
            if(str(onStreet) != 'nan'):
                loc = onStreet
            elif(str(crossStreet) != 'nan'):
                loc = crossStreet
            elif(str(offStreet) != 'nan'):
                loc = offStreet
            else : loc = "unknown location"
            print(" location : ",loc)

            print("#######################################")
            folium.Marker([lat, lon],popup=loc,tooltip=loc,icon=folium.Icon(colour="red")).add_to(boroughMap)

            # Save the file created above
        baseDir = Path(__file__).resolve().parent.parent
        # crashDataPath = os.path.join(baseDir, 'static', r'Motor_Vehicle_Collisions_-_Crashes.csv')
        mapSavePath = os.path.join(baseDir, 'Template', r'boroughMap.html')
        boroughMap.save(mapSavePath)

        return render(request, "boroughMap.html")

class loadBikeStaionData(View):
    def get(self, request, *args, **kwargs):
        BikeStation.objects.all().delete()
        print("existing data cleared..")
        baseDir = Path(__file__).resolve().parent.parent
        # crashDataPath = os.path.join(baseDir, 'static', r'Motor_Vehicle_Collisions_-_Crashes.csv')
        bikeStationPath = os.path.join(baseDir, 'static', r'201901-citibike-tripdata.csv')
        print("bike station data located..")
        bikeStationData = pd.read_csv(bikeStationPath,usecols=['start station name', 'start station latitude',
       'start station longitude', 'end station name',
       'end station latitude', 'end station longitude'],nrows=1000,low_memory=False)

        bikeStationObjs = []
        for index,row in bikeStationData.iterrows():

            eachStartStationObj = BikeStation(StationName=row['start station name'],StationLocationLat=row['start station latitude'],
                                               StationLocationLon=row['start station longitude'])
            bikeStationObjs.append(eachStartStationObj)
            eachEndStationObj = BikeStation(StationName=row['end station name'],StationLocationLat=row['end station latitude'],
                                               StationLocationLon=row['end station longitude'])
            bikeStationObjs.append(eachEndStationObj)
        BikeStation.objects.bulk_create(bikeStationObjs)

        print(" bulk updation performed for bike stations !!! ")
        return render(request, "index.html")

class showBikesAndCrashesView(View):
    def get(self, request, *args, **kwargs):
        stationData = pd.DataFrame(list(BikeStation.objects.values()))
        print(stationData.shape)

        lattitude_list = list(stationData['StationLocationLat'])
        longitude_list = list(stationData['StationLocationLon'])

        locZip = list(zip(lattitude_list, longitude_list))
        locs = [(lat, lon) for (lat, lon) in locZip if
                ((str(lat) not in ('nan', '')) and (str(lon) not in ('nan', '')))]
        # print(sorted(locs))
        # print(set([(type(lat), type(lon)) for (lat, lon) in locs]))
        meanLat = sum([float(lat) for (lat, lon) in locs]) / len([lat for (lat, lon) in locs])
        meanLon = sum([float(lon) for (lat, lon) in locs]) / len([lon for (lat, lon) in locs])
        print(meanLat, meanLon)
        station_Crash_Map = folium.Map(location=[meanLat, meanLon], zoom_start=13)
        # folium.LayerControl().add_to(station_Crash_Map)
        # marker_cluster = MarkerCluster().add_to(station_Crash_Map)
        for (lat, lon, stationName) in zip(stationData['StationLocationLat'], stationData['StationLocationLon'],stationData['StationName']):
            # Marker() takes location coordinates
            # as a list as an argument
            folium.Marker([lat, lon], popup=stationName, tooltip=stationName, icon=folium.Icon(color='darkblue', icon_color='white', icon='motorcycle', angle=0, prefix='fa')).add_to(station_Crash_Map)
            #fa fa-exclamation-triangle
            #marker_cluster.add_to(station_Crash_Map)

            # Save the file created above

        crashData = pd.DataFrame(list(CollisionLocation.objects.values()))

        crashData.drop(crashData[(crashData['lattitude'] == '') | (crashData['longitude'] == '')].index, inplace=True)
        print("data read complete from the collision location model")
        print(crashData.shape)

        for (lat, lon, onStreet, crossStreet, offStreet) in zip(crashData['lattitude'], crashData['longitude'],
                                                                crashData['onStreetName'], crashData['crossStreetName'],
                                                                crashData['offStreetName']):
            # Marker() takes location coordinates
            # as a list as an argument
            print("[ ", onStreet, " ]#####[ ", crossStreet, " ]##########[ ", offStreet, " ]")
            if (str(onStreet) != 'nan'):
                loc = onStreet
            elif (str(crossStreet) != 'nan'):
                loc = crossStreet
            elif (str(offStreet) != 'nan'):
                loc = offStreet
            else:
                loc = "unknown location"
            print(" location : ", loc)

            print("#######################################")
            folium.Marker([lat, lon], popup=loc, tooltip=loc, icon=folium.Icon(color='red', icon_color='white', icon='exclamation-triangle', angle=0, prefix='fa')).add_to(station_Crash_Map)

        baseDir = Path(__file__).resolve().parent.parent
        # crashDataPath = os.path.join(baseDir, 'static', r'Motor_Vehicle_Collisions_-_Crashes.csv')
        mapSavePath = os.path.join(baseDir, 'Template', r'stationCrashMap.html')
        station_Crash_Map.save(mapSavePath)

        return render(request, "stationCrashMap.html")









        

